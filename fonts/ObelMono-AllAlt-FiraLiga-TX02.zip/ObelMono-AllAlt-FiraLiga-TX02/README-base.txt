Obel Mono AllAlt Fira Liga
==========================

在 Obel Mono AllAlt 基础上，移植所提供 FiraCode-VF.ttf（6.002）中的
默认编程符号连字及其上下文规则，生成独立命名的字体。

新字体家族：
  Obel Mono AllAlt Fira Liga
  Obel Mono Masked AllAlt Fira Liga（默认开启秘密遮罩，可选）

推荐桌面安装
------------
macOS 双击以下两个可变 TTF，在字体册中安装：
  ObelMono/ttf/variable/ObelMonoAllAltFiraLiga[wght].ttf
  ObelMono/ttf/variable/ObelMonoAllAltFiraLiga-Italic[wght].ttf

然后在应用中选择：Obel Mono AllAlt Fira Liga。
这两个文件覆盖 100–900 字重、正体和斜体。
不支持可变字体的应用可安装 ttf/static/ 下的对应字重。
同一样式选择一种格式安装，避免静态版与可变版重复。
本包不会自动安装或移除系统字体。

macOS CoreText 的等宽识别与基础 AllAlt 相同：静态版具有等宽标签，
4 个可变文件未获 traitMonoSpace 标签，但实际字符网格仍固定为 1200。
如果应用按该标签筛选字体而没有显示可变版，可改装静态 TTF。

开启连字
--------
新增连字使用 OpenType calt（Contextual Alternates）。应用必须支持
字体塑形，并启用 calt；关闭 calt 就恢复 AllAlt 的原有排版。
普通字符编码、复制得到的文本以及原有 AllAlt 字形映射保持不变。

VS Code / Cursor 的设置示例：
  "editor.fontFamily": "Obel Mono AllAlt Fira Liga, monospace",
  "editor.fontLigatures": true

Web 可使用各家族 woff2/obel-mono.css；其中的家族名和文件名已更新：
  font-family: "Obel Mono AllAlt Fira Liga", monospace;
  font-feature-settings: "calt" 1;

连字内容
--------
包含 Fira Code 默认符号规则中的箭头、比较、逻辑、注释、标点、序列
连接等，例如：
  -> --> <-> => <=> != !== == === <= >= << >>
  :: ::: := && || |> <| <|> ++ +++ ** ***
  // /// /* */ <!-- ... ..= ?. ?? </ /> www

每个字体新增 178 个连字、spacer 和序列辅助字形；补充 277 个 GSUB
lookup，保留源规则顺序、边界守卫及连续符号的 start/middle/end 形式。
原有 1937 个字形保留，新字体共 2115 个字形，字符槽仍为 1200 单位。
完整清单、测试字符串和具体结果在 verification/ 中。

保留 AllAlt
-----------
AllAlt 已设为默认的 ss02 与 cv01–cv16 字形映射保持不变，包括圆点零、
单层 a、带尾 i/l/j/t、g/f/y 以及语言替代形式。
Fira 的普通字母与希腊语替换规则不移植，以保留 AllAlt 字母及组合重音
的外观和定位。Fira 的符号上下文规则随连字一起移植，可能调整相邻
符号的形态或位置。Fira 的可选 ss/cv 样式开关未引入，避免与 AllAlt
现有同名开关冲突。

普通版仍可通过 ss01 开启秘密遮罩；Masked 版保持默认遮罩。
遮罩先于新增连字执行。它是视觉功能，复制仍得到原始字符。

字重、比例与斜体
----------------
Fira Code 原生 wght 范围为 300–700，AllAlt 为 100–900。
在 300–700 范围按相同字重取 Fira 轮廓；100/200 的连字使用 Fira 300，
800/900 的连字使用 Fira 700。AllAlt 原有字母仍使用它本来的对应字重。
因此最细、最粗字重中的连字与字母可能有粗细差别。

两种字体的等宽单元均为 1200，因此连字轮廓按 1:1 移植、不平移，
保持原来的基线与字符网格。可变数据在 AllAlt 的 avar 空间重新构建。
Fira 源文件没有斜体；本包的斜体连字按 Obel 的 8.75° 进行几何倾斜。
新增字形不带 Fira 的原始 hinting；原有 AllAlt 轮廓和 hinting 保留。

内容
----
80 个字体文件，普通版和 Masked 版各含全部正体、斜体及 9 档命名字重：
  ttf/variable/  4 个可变 TTF（两个家族合计）
  ttf/static/   36 个静态 TTF
  otf/          36 个静态 CFF OTF
  woff2/        4 个可变 WOFF2 与对应 CSS

verification/ 包含构建脚本、输入 SHA-256、字体轮廓和排版检查、macOS
原生加载与连字检查、12/16 px 预览以及 REPORT.md。
README-AllAlt.txt 是基础 AllAlt 版本说明。

复现（从上级工作目录运行）
--------------------------
要求相邻目录中的 ObelMono-AllAlt、原始 FiraCode-VF.ttf，以及现有
.font-venv、HarfBuzz CLI；原生验证需 macOS Swift/CoreText，预览需 ImageMagick。

  .font-venv/bin/python ObelMono-AllAlt-FiraLiga/verification/build_ligatures.py
  .font-venv/bin/python ObelMono-AllAlt-FiraLiga/verification/verify_ligatures.py
  swift ObelMono-AllAlt-FiraLiga/verification/verify_macos.swift ObelMono-AllAlt-FiraLiga
  .font-venv/bin/python ObelMono-AllAlt-FiraLiga/verification/render_ligatures.py

许可与来源
----------
Obel Mono 与 Fira Code 均为 SIL Open Font License 1.1。
保留两者的版权信息、OFL.txt、OFL-FiraCode.txt 和 AUTHORS.txt。
Fira Code：https://github.com/tonsky/FiraCode
Obel Mono：https://typographic.systems/obel-mono

本包以 AllAlt 为基础，不包含先前 TX02 改版的括号或连字。
原始 AllAlt、FiraCode-VF.ttf 和其他既有字体文件均保持不变。
