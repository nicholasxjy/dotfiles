"""Render the original and generated fonts side by side."""
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

OUT = Path(__file__).resolve().parents[1]
BASE = OUT.parent / 'ObelMono-AllAlt-FiraLiga'
TEXT = '() {} []  ([{abc}])\nif (a != b) => foo(bar[0], {x: y});\n-> => !== === <= >= && || ...'


def main():
    with TemporaryDirectory() as temp:
        images = []
        for weight in [100, 400, 700]:
            for italic in [False, True]:
                for root, label in [(BASE, 'Original'), (OUT, 'TX02 brackets')]:
                    prefix = 'ObelMonoAllAltFiraLiga' + ('TX02' if root == OUT else '')
                    font = root / 'ObelMono/ttf/variable' / f'{prefix}{"-Italic" if italic else ""}[wght].ttf'
                    assert font.is_file(), font
                    png = Path(temp) / f'{len(images)}.png'
                    subprocess.run(['hb-view', str(font), '--text=' + TEXT, '--font-size=20',
                                    '--font-ppem=20', '--font-funcs=ft', '--face-loader=ft',
                                    '--features=calt=1,ss01=0', '--variations=wght=' + str(weight),
                                    '--margin=14', '--line-space=6', '--output-file=' + str(png)], check=True)
                    title = f'{label} / {weight} / {"Italic" if italic else "Upright"} / 20px'
                    subprocess.run(['magick', str(png), '-background', '#edf0f4', '-gravity', 'north',
                                    '-splice', '0x28', '-font', '/System/Library/Fonts/Helvetica.ttc',
                                    '-pointsize', '13', '-fill', '#263140', '-annotate', '+0+7', title, str(png)], check=True)
                    images.append(str(png))
        dest = OUT / 'verification/comparison.png'
        subprocess.run(['magick', 'montage', *images, '-tile', '2x', '-geometry', '+5+5',
                        '-background', '#cbd2dc', str(dest)], check=True)
        assert dest.stat().st_size > 0
        print(dest)


if __name__ == '__main__':
    main()
