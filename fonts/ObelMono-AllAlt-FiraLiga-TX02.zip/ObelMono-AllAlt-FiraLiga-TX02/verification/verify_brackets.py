"""Check that only the six TX-02 brackets and font identity changed."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

from fontTools.pens.recordingPen import DecomposingRecordingPen
from fontTools.pens.transformPen import TransformPen
from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'ObelMono-AllAlt-FiraLiga'
OUT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'TX-02-Variable.ttf'
GLYPHS = {'parenleft', 'parenright', 'braceleft', 'braceright', 'bracketleft', 'bracketright'}
SLANT = -8.619224379350428
sys.path.insert(0, str(BASE / 'verification'))
from freetype_check import outline


def renamed(path):
    return Path(str(path).replace('AllAltFiraLiga', 'AllAltFiraLigaTX02'))


def drawing(font, glyph, location=None, scale=1):
    glyphset = font.getGlyphSet(location=location)
    pen = DecomposingRecordingPen(glyphset)
    glyphset[glyph].draw(TransformPen(pen, (scale, 0, 0, scale, 0, 0)))
    return pen.value


def distance(actual, expected):
    assert len(actual) == len(expected), (len(actual), len(expected))
    error = 0
    for (op, points), (expected_op, expected_points) in zip(actual, expected):
        assert op == expected_op and len(points) == len(expected_points)
        for point, expected_point in zip(points, expected_points):
            if point is None or expected_point is None:
                assert point == expected_point
            else:
                error = max(error, ((point[0] - expected_point[0]) ** 2 + (point[1] - expected_point[1]) ** 2) ** .5)
    return error


def shape(path, text, features):
    return subprocess.check_output(['hb-shape', str(path), '--text=' + text,
                                    '--features=' + features, '--output-format=json'], text=True)


def main():
    assert __debug__, 'Run without -O: validation requires assertions'
    inputs = json.loads((OUT / 'verification/input-sha256.json').read_text())
    source = TTFont(SOURCE)
    files = sorted(p for p in BASE.rglob('*') if p.suffix in {'.ttf', '.otf', '.woff2'})
    assert len(files) == 80
    preserved = checks = ft_checks = 0
    max_error = 0
    output_hashes = {}
    samples = ['() {} []', 'if (a != b && c <= d) => foo(bar[0], {key: value});',
               '#( #{ #[ #_( {| |} [| |] ]#', '-> --> => <=> != !== == === <= >= :: && || ... www',
               'ailjtgfy 01 * $ @', 'GITHUB_TOKEN=' + 'AbCd' + 'abcdef0123456789' * 2]
    for path in files:
        relative = renamed(path.relative_to(BASE))
        output = OUT / relative
        base, font = TTFont(path), TTFont(output)
        assert base.getGlyphOrder() == font.getGlyphOrder(), relative
        assert base.keys() == font.keys(), relative
        assert 'AllAlt Fira Liga TX02' in font['name'].getBestFamilyName()
        for tag in base.keys():
            if tag not in {'GlyphOrder', 'head', 'maxp', 'loca', 'glyf', 'gvar', 'hmtx', 'CFF ', 'name'}:
                assert base.getTableData(tag) == font.getTableData(tag), (relative, tag)
        for glyph in base.getGlyphOrder():
            if glyph in GLYPHS:
                assert font['hmtx'][glyph][0] == 1200
                continue
            assert base['hmtx'][glyph] == font['hmtx'][glyph], (relative, glyph, 'hmtx')
            if 'glyf' in font:
                assert base['glyf'][glyph].compile(base['glyf']) == font['glyf'][glyph].compile(font['glyf']), (relative, glyph, 'glyf')
                if 'gvar' in font:
                    assert base['gvar'].variations[glyph] == font['gvar'].variations[glyph], (relative, glyph, 'gvar')
            else:
                assert drawing(base, glyph) == drawing(font, glyph), (relative, glyph, 'CFF')
            preserved += 1
        italic = font['post'].italicAngle != 0
        weights = sorted(set(range(100, 901, 25)) | {375, 425, 650}) if 'fvar' in font else [font['OS/2'].usWeightClass]
        for weight in weights:
            target_location = {'wght': weight} if 'fvar' in font else None
            source_location = {'wght': weight, 'wdth': 100, 'slnt': SLANT if italic else 0}
            for glyph in sorted(GLYPHS):
                if 'glyf' in font:
                    error = distance(drawing(font, glyph, target_location), drawing(source, glyph, source_location, 2))
                    assert error < 1.5, (relative, weight, glyph, error)
                    max_error = max(max_error, error)
                else:
                    # The existing TX02 conversion is an independent CFF reference.
                    donor_path = ROOT / 'ObelMono-TX02' / Path(str(path.relative_to(BASE)).replace('AllAltFiraLiga', 'TX02'))
                    with TTFont(donor_path) as donor:
                        assert drawing(font, glyph) == drawing(donor, glyph), (relative, glyph, 'TX02 CFF reference')
                checks += 1
        for char in '(){}[]':
            data = outline(output, char)
            assert data['advance'] == 1200 and data['points'] and data['contours'], (relative, char)
            ft_checks += 1
        with TemporaryDirectory() as temp:
            shaping_paths = [path, output]
            if path.suffix == '.woff2':
                # This HarfBuzz CLI needs decompressed SFNT files for shaping.
                shaping_paths = [Path(temp) / 'base.ttf', Path(temp) / 'output.ttf']
                for current, dest in zip([base, font], shaping_paths):
                    current.flavor = None
                    current.save(dest)
            for sample in samples:
                for features in ['calt=0,ss01=0', 'calt=1,ss01=0', 'calt=1,ss01=1']:
                    assert shape(shaping_paths[0], sample, features) == shape(shaping_paths[1], sample, features), (relative, sample, features)
        output_hashes[str(relative)] = sha256(output.read_bytes()).hexdigest()
        base.close()
        font.close()
        print('PASS', relative, flush=True)
    for path, expected in inputs.items():
        assert sha256((ROOT / path).read_bytes()).hexdigest() == expected, ('input changed', path)
    result = {'status': 'PASS', 'font_files': len(files), 'unchanged_other_glyphs': preserved,
              'bracket_outline_checks': checks, 'max_TTF_outline_error_units': max_error,
              'freetype_bracket_checks': ft_checks, 'shaping_comparisons': len(files) * len(samples) * 3,
              'input_hashes_unchanged': len(inputs), 'output_sha256': output_hashes}
    (OUT / 'verification/results.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'output_sha256'}, indent=2))


if __name__ == '__main__':
    main()
