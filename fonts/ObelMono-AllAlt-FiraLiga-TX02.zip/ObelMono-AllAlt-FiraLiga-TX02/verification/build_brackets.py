"""Apply the existing TX-02 bracket transplant to AllAlt Fira Liga."""
from copy import deepcopy
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
from shutil import copy2

from fontTools.misc.roundTools import otRound
from fontTools.pens.t2CharStringPen import T2CharStringPen

OUT = Path(__file__).resolve().parents[1]
ROOT = OUT.parent
BASE = ROOT / 'ObelMono-AllAlt-FiraLiga'
HELPER = ROOT / 'ObelMono-TX02/verification/build_fonts.py'
spec = importlib.util.spec_from_file_location('tx02_brackets', HELPER)
tx = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tx)


def renamed(text):
    return text.replace('AllAltFiraLiga', 'AllAltFiraLigaTX02').replace('AllAlt Fira Liga', 'AllAlt Fira Liga TX02')


tx.renamed = renamed


def update_names(font, source):
    notice = font['CFF '].cff.topDictIndex[0].Notice if 'CFF ' in font else None
    tx.update_names(font, source)
    if notice is not None:
        font['CFF '].cff.topDictIndex[0].Notice = notice + ' TX-02 brackets under the embedded personal LT-02 license; see LICENSE-TX02.txt.'


def main():
    assert __debug__, 'Run without -O: validation requires assertions'
    verification = OUT / 'verification'
    verification.mkdir(parents=True, exist_ok=True)
    files = sorted(p for p in BASE.rglob('*') if p.suffix in {'.ttf', '.otf', '.woff2'})
    assert len(files) == 80
    manifest_path = verification / 'input-sha256.json'
    if manifest_path.exists():
        for path, digest in json.loads(manifest_path.read_text()).items():
            assert sha256((ROOT / path).read_bytes()).hexdigest() == digest, path
    manifest = {str(p.relative_to(ROOT)): sha256(p.read_bytes()).hexdigest() for p in [tx.SOURCE, HELPER, *files]}
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    source = tx.opened(tx.SOURCE)
    summary = {'base': BASE.name, 'source': tx.SOURCE.name, 'characters': tx.CHARS,
               'scale': 2, 'translate': [0, 0], 'wdth': 100, 'slnt_upright': 0,
               'slnt_italic': tx.SLANT, 'families': ['Obel Mono AllAlt Fira Liga TX02',
               'Obel Mono Masked AllAlt Fira Liga TX02'], 'positions': {}}
    vfs = {}
    for path in sorted(BASE.glob('*/ttf/variable/*.ttf')):
        font = tx.opened(path)
        italic = 'Italic' in path.name
        relative = tx.output_relative(path.relative_to(BASE))
        summary['positions'][str(relative)] = tx.rebuild_variations(source, font, italic)
        update_names(font, source)
        dest = OUT / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        font.save(dest)
        vfs[(path.relative_to(BASE).parts[0], italic)] = tx.opened(dest)
        font.close()
        print('Built', relative, flush=True)
    for path in files:
        if 'variable' in path.parts:
            continue
        relative = tx.output_relative(path.relative_to(BASE))
        dest = OUT / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        vf = vfs[(path.relative_to(BASE).parts[0], 'Italic' in path.name)]
        if path.suffix == '.woff2':
            font = deepcopy(vf)
            font.flavor = 'woff2'
        else:
            font = tx.opened(path)
            for char in tx.CHARS:
                name = font.getBestCmap()[ord(char)]
                glyph = tx.instance_glyph(vf, char, font['OS/2'].usWeightClass)
                if 'glyf' in font:
                    tx.install_glyph(font, name, glyph)
                else:
                    top = font['CFF '].cff.topDictIndex[0]
                    assert top.Private.defaultWidthX == 1200
                    pen = T2CharStringPen(None, None, roundTolerance=0)
                    glyph.draw(pen, None)
                    top.CharStrings[name] = pen.getCharString(private=top.Private, globalSubrs=font['CFF '].cff.GlobalSubrs, optimize=False)
                    font['hmtx'][name] = (1200, min(otRound(x) for x, y in glyph.coordinates))
            update_names(font, source)
        font.save(dest)
        font.close()
        print('Built', relative, flush=True)
    for path in BASE.glob('*/woff2/obel-mono.css'):
        (OUT / path.relative_to(BASE)).write_text(renamed(path.read_text()))
    for name in ['OFL.txt', 'OFL-FiraCode.txt', 'AUTHORS.txt']:
        copy2(BASE / name, OUT / name)
    copy2(BASE / 'README.txt', OUT / 'README-base.txt')
    copy2(ROOT / 'ObelMono-TX02/LICENSE-TX02.txt', OUT / 'LICENSE-TX02.txt')
    (verification / 'build-parameters.json').write_text(json.dumps(summary, indent=2) + '\n')
    assert len(list(OUT.rglob('*.ttf'))) == 40
    assert len(list(OUT.rglob('*.otf'))) == 36
    assert len(list(OUT.rglob('*.woff2'))) == 4
    for path, digest in manifest.items():
        assert sha256((ROOT / path).read_bytes()).hexdigest() == digest, path
    print('Completed 80 fonts; all inputs unchanged.', flush=True)


if __name__ == '__main__':
    main()
