# Obel Mono AllAlt Fira Liga TX02 验证记录

基础：`ObelMono-AllAlt-FiraLiga`。仅替换 `() {} []` 六个独立括号，来源为工作目录中的 `TX-02-Variable.ttf`。新家族名为 `Obel Mono AllAlt Fira Liga TX02` 与 `Obel Mono Masked AllAlt Fira Liga TX02`。

生成 80 个字体：40 个 TTF、36 个静态 CFF OTF、4 个可变 WOFF2，覆盖两家族、正体/斜体、100–900 字重。每个文件仍有 2115 个字形。原有 Fira 连字、AllAlt 默认替代字形、秘密遮罩与字符编码保持原样。

TX-02 六括号按 2 倍缩放至 2000 UPM，使用源 wdth=100 和相同用户字重。斜体沿用既有移植方案校准后的 slnt=-8.619224379350428。可变轮廓按源与目标 avar 的转折点重新构建，每字符维持 1200 字宽。

## 自动核对

结果：**PASS**。80 个字体全部通过；168,720 项其它字形检查不变，2,016 次括号轮廓对照和 1,440 组排版对照通过。TTF 轮廓相对直接缩放后源轮廓的最大点距离为 0.67961208 字体单位（1 单位 = 1/2000 em）。82 个输入字体及复用脚本的 SHA-256 不变。

`verify_brackets.py` 的完整结果与输出 SHA-256 见 `results.json`。检查内容包括：

- 80 个字体的字形顺序、字符映射、未改动的字体表、全部其它字形轮廓/度量及 gvar。
- TTF 与 WOFF2 六括号在命名字重、中间字重的轮廓，对照直接从 TX-02 取出的等比轮廓；OTF 六括号对照既有已验证的 TX02 CFF 转换。
- 开关 calt、开关 ss01 时的括号、编程连字、字母及遮罩文本排版，对照基础字体；本机 HarfBuzz CLI 的 WOFF2 排版通过临时解压后的 SFNT 检查。
- 输入字体和复用构建脚本的 SHA-256 未变。

额外运行既有 `freetype_check.py --check ObelMono-AllAlt-FiraLiga-TX02`：80 个字体、1008 次括号轮廓及字宽检查通过，失败 0，含可变字体默认值、100–900 命名字重及 450/650 中间值。

## macOS 原生检查

`macos-results.json` 记录 76 个桌面 TTF/OTF 全部成功在验证进程中注册，684 次默认字形检查、1140 次括号和连字排版检查通过，失败 0。

等宽特征与基础字体一致：静态字体具有 CoreText 的 traitMonoSpace；4 个可变 TTF 与基础文件一样未获得该标签，但实际字距、isFixedPitch 和等宽网格均保留。按该标签筛选字体的应用可改装静态 TTF。

未执行系统持久安装。

## 视觉检查及范围

`comparison.png` 为实际新字体与基础字体的并排渲染：100/400/700 字重、正体和斜体、20px，展示括号、嵌套括号、代码及 Fira 连字。

只移植六个独立括号。`{|`、`[|`、`#(` 等现有 Fira 组合连字继续使用原有 Fira 连字轮廓。没有逐个测试所有编辑器、终端或 Windows/Linux。TX-02 材料沿用其个人许可，不能仅按基础字体的 OFL 视为可自由分发。

复现命令及安装入口见根目录 `README.txt`；基础字体的既有限制见 `README-base.txt`。
