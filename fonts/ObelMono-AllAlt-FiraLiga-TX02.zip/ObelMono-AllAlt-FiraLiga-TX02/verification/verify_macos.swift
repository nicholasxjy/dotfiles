// Register fonts only for this process; leave the user's installed fonts intact.
import Foundation
import CoreText

let root = URL(fileURLWithPath: CommandLine.arguments.dropFirst().first ?? "ObelMono-AllAlt-FiraLiga-TX02")
let files = FileManager.default.enumerator(at: root, includingPropertiesForKeys: nil)!
let urls = files.compactMap { $0 as? URL }
    .filter { ["ttf", "otf"].contains($0.pathExtension.lowercased()) }
    .sorted { $0.path < $1.path }
var failures: [[String: String]] = []
var registered = 0
var cmapChecks = 0
var shapingChecks = 0
var inheritedNonMonospaceTraits = 0
var monospaceTraitMismatches = 0
struct NativeCase: Decodable {
    let text: String
    let glyph_ids: [UInt16]
}
let nativeCases = try JSONDecoder().decode([NativeCase].self, from: Data(contentsOf: root.appendingPathComponent("verification/native-cases.json")))
let samples: [(UInt16, String)] = [
    (0x0030, "zero.dot"), (0x0031, "one.plain"),
    (0x0061, "a.ductus"), (0x0067, "g.ductus"),
    (0x0069, "i.ductus"), (0x006C, "l.ductus"),
    (0x002A, "asterisk.math"), (0x0024, "dollar.broken"), (0x0040, "at.open")
]
for url in urls {
    let descriptors = CTFontManagerCreateFontDescriptorsFromURL(url as CFURL) as? [CTFontDescriptor] ?? []
    guard !descriptors.isEmpty else {
        failures.append(["path": url.path, "error": "CoreText returned no font descriptors"])
        continue
    }
    var error: Unmanaged<CFError>?
    guard CTFontManagerRegisterFontsForURL(url as CFURL, .process, &error) else {
        failures.append(["path": url.path, "error": error.map { String(describing: $0.takeRetainedValue()) } ?? "Registration failed"])
        continue
    }
    registered += 1
    let provider = CGDataProvider(url: url as CFURL)!
    let graphics = CGFont(provider)!
    let font = CTFontCreateWithGraphicsFont(graphics, 16, nil, nil)
    if !(CTFontCopyFamilyName(font) as String).contains("AllAlt Fira Liga TX02") {
        failures.append(["path": url.path, "error": "Unexpected font family"])
    }
    for (codepoint, name) in samples {
        var character = codepoint
        var glyph: CGGlyph = 0
        let found = CTFontGetGlyphsForCharacters(font, &character, &glyph, 1)
        let expected = CTFontGetGlyphWithName(font, name as CFString)
        if !found || expected == 0 || glyph != expected {
            failures.append(["path": url.path, "error": "Default glyph mismatch: " + name])
        }
        cmapChecks += 1
    }
    let relative = String(url.path.dropFirst(root.path.count + 1))
    let baseRelative = relative.replacingOccurrences(of: "ObelMonoMaskedAllAltFiraLigaTX02", with: "ObelMonoMaskedAllAltFiraLiga")
        .replacingOccurrences(of: "ObelMonoAllAltFiraLigaTX02", with: "ObelMonoAllAltFiraLiga")
    let baseURL = root.deletingLastPathComponent().appendingPathComponent("ObelMono-AllAlt-FiraLiga").appendingPathComponent(baseRelative)
    let baseProvider = CGDataProvider(url: baseURL as CFURL)!
    let baseGraphics = CGFont(baseProvider)!
    let baseFont = CTFontCreateWithGraphicsFont(baseGraphics, 16, nil, nil)
    let monospace = CTFontGetSymbolicTraits(font).contains(.traitMonoSpace)
    let baseMonospace = CTFontGetSymbolicTraits(baseFont).contains(.traitMonoSpace)
    if monospace != baseMonospace {
        monospaceTraitMismatches += 1
        failures.append(["path": url.path, "error": "Monospace trait differs from AllAlt base"])
    }
    if !monospace && !baseMonospace {
        inheritedNonMonospaceTraits += 1
    }
    for sample in nativeCases {
        let attributes = [kCTFontAttributeName: font, kCTLigatureAttributeName: 1] as CFDictionary
        let attributed = CFAttributedStringCreate(nil, sample.text as CFString, attributes)!
        let line = CTLineCreateWithAttributedString(attributed)
        let runs = CTLineGetGlyphRuns(line) as! [CTRun]
        var actual: [CGGlyph] = []
        for run in runs {
            var glyphs = [CGGlyph](repeating: 0, count: CTRunGetGlyphCount(run))
            CTRunGetGlyphs(run, CFRange(location: 0, length: 0), &glyphs)
            actual += glyphs
        }
        if actual != sample.glyph_ids {
            failures.append(["path": url.path, "error": "Native ligature mismatch: " + sample.text])
        }
        shapingChecks += 1
    }
    CTFontManagerUnregisterFontsForURL(url as CFURL, .process, nil)
}
let result: [String: Any] = [
    "desktop_font_files": urls.count,
    "coretext_process_registrations": registered,
    "native_default_glyph_checks": cmapChecks,
    "native_ligature_shaping_checks": shapingChecks,
    "monospace_traits_preserved": monospaceTraitMismatches == 0,
    "inherited_non_monospace_symbolic_traits": inheritedNonMonospaceTraits,
    "failures": failures,
    "persistent_installation_performed": false
]
let data = try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys])
try data.write(to: root.appendingPathComponent("verification/macos-results.json"))
print(String(data: data, encoding: .utf8)!)
exit(failures.isEmpty && urls.count == 76 ? 0 : 1)
