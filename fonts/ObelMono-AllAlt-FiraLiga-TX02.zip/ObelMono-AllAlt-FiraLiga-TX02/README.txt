Obel Mono AllAlt Fira Liga TX02
==============================

以 ObelMono-AllAlt-FiraLiga 为基础，仅将 () {} [] 六个独立括号字形
替换成所提供 TX-02-Variable.ttf 的对应字形，并生成独立命名的字体。

家族名：
  Obel Mono AllAlt Fira Liga TX02
  Obel Mono Masked AllAlt Fira Liga TX02（默认启用秘密遮罩）

推荐安装
--------
普通版正体、斜体可变 TTF：
  ObelMono/ttf/variable/ObelMonoAllAltFiraLigaTX02[wght].ttf
  ObelMono/ttf/variable/ObelMonoAllAltFiraLigaTX02-Italic[wght].ttf

在编辑器中选择 Obel Mono AllAlt Fira Liga TX02。
VS Code / Cursor 可设置：
  "editor.fontFamily": "Obel Mono AllAlt Fira Liga TX02, monospace",
  "editor.fontLigatures": true

不支持可变字体的应用可选 ttf/static/ 中的静态 TTF。
同一家族、同一样式选择可变版或一种静态格式安装，避免重复。
本包不会自动安装字体；基础字体和 TX-02 源文件保持不变。

内容与替换范围
--------------
共 80 个字体文件：40 个 TTF、36 个 OTF、4 个 WOFF2。
普通版和 Masked 版各有 100–900 字重、正体与斜体。
保留基础字体的 AllAlt 默认替代字形、字符映射、等宽字距、行高、
Fira 编程连字和秘密遮罩功能。

仅替换 U+0028、U+0029、U+005B、U+005D、U+007B、U+007D 的字形。
{|、[|、#( 等 Fira 组合连字沿用基础包的原有连字轮廓。
因此开启 calt 后，这些组合仍会显示 Fira 的连字设计。

TX-02 轮廓由 1000 UPM 等比放大至 2000 UPM；无平移，字宽固定 1200。
使用源 wdth=100、相同 wght=100–900；正体 slnt=0，斜体
slnt=-8.619224379350428，沿用已校准至 Obel 8.75 度的参数。
可变字重在目标 avar 坐标空间重新构建；替换字形不携带源 hinting。

验证与复现
----------
verification/results.json：所有字体结构、轮廓、排版和输入校验结果。
verification/macos-results.json：macOS CoreText 进程内加载与排版结果。
verification/comparison.png：基础版与新字体的实际渲染对照。
README-base.txt：基础 AllAlt Fira Liga 版本的完整说明和既有限制。

从上级 ObelMono 工作目录运行：
  .font-venv/bin/python ObelMono-AllAlt-FiraLiga-TX02/verification/build_brackets.py
  .font-venv/bin/python ObelMono-AllAlt-FiraLiga-TX02/verification/verify_brackets.py
  swift ObelMono-AllAlt-FiraLiga-TX02/verification/verify_macos.swift ObelMono-AllAlt-FiraLiga-TX02

构建复用相邻 ObelMono-TX02/verification/build_fonts.py 的移植逻辑，
需要相邻基础字体目录、TX-02-Variable.ttf 和已有 .font-venv。
验证 CFF 时还使用既有 ObelMono-TX02 的对应 OTF 作为独立参考。
未逐个测试编辑器、终端或 Windows/Linux，也未持久安装字体。

来源与许可
----------
保留 Obel Mono、Fira Code 和 TX-02 的作者、版权及许可信息。
OFL.txt / AUTHORS.txt：Obel Mono；OFL-FiraCode.txt：Fira Code。
LICENSE-TX02.txt：TX-02 源文件内的个人授权说明。
合成字体包含 TX-02 轮廓，不能仅按 Obel/Fira 的 OFL 视为可自由分发。
原始 TX-02 字体不会作为独立字体附在新包中。
