Obel Mono TX02 Fira Liga 450 900
==============================

以 ObelMono-TX02-FiraLiga 的普通版可变 TTF 为基础，只保留四个静态样式：

  文件后缀          应用内样式       原可变轴 wght    样式字重标记
  Regular.ttf       Regular            450              400
  RegularItalic.ttf Italic             450              400
  Bold.ttf          Bold               900              700
  BoldItalic.ttf    Bold Italic        900              700

字体家族名称：Obel Mono TX02 Fira Liga 450 900
文件名前缀：  ObelMonoTX02FiraLiga450900-

450 / 900 是从原始可变字体提取轮廓时使用的实际字重坐标；400 / 700
仅为静态字体的标准 Regular / Bold 元数据，使编辑器和应用能够正确
切换加粗、斜体及粗斜体。没有把字形改回原来的 400 / 700。
Regular Italic 按通用四样式约定在字体内部命名为 Italic。

安装与使用
----------
安装 ttf/ 中的四个文件，然后在应用中选择上述家族名称。
本包使用独立家族名和 PostScript 名称，可与原版并存。
本包未自动安装系统字体。

VS Code / Cursor：
  "editor.fontFamily": "Obel Mono TX02 Fira Liga 450 900, monospace",
  "editor.fontWeight": "normal",
  "editor.fontLigatures": true

请使用 normal / bold（或 400 / 700）选择样式；文件已经固定为原可变
轴的 450 / 900，无需在编辑器中再次设置为 450 / 900。

原有 TX02 括号、等宽网格、字形覆盖、默认七项 Fira 样式、编程连字、
全部可选 OpenType 功能及遮罩开关均保留。详见 FEATURES.md。
每个样式包含 2274 个字形。

本包仅包含普通家族的四个静态 TTF，不包含可变字体、其他字重、
Masked 家族或其他字体格式。

验证与复现
----------
verification/results.json 记录原文件哈希、输出哈希、全部字形轮廓与
原可变轴坐标的对照，以及 HarfBuzz 的连字、重音和定位对照。
verification/macos-results.json 记录 CoreText 进程级注册、等宽标签、
原生连字与四种样式的自动选择检查。

在原工作区的上级目录运行（需同级 ObelMono-TX02-FiraLiga）：
  .font-venv/bin/python ObelMono-TX02-FiraLiga-450-900/verification/build_fonts.py

依赖 fontTools、hb-shape；macOS 原生校验另需 Swift / CoreText。
构建脚本的轮廓自检允许最多 1 个字体单位的整数取整误差。

许可
----
沿用源字体许可，见 AUTHORS.txt、OFL.txt、OFL-FiraCode.txt 和
LICENSE-TX02.txt；字体内部版权、商标和许可文本保留。
TX02 的个人使用限制继续适用。
