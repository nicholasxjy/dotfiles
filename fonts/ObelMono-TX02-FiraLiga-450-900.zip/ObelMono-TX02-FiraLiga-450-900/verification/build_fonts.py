"""Freeze the original variable fonts at 450/900 and link four desktop styles."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

import fontTools
from fontTools.pens.recordingPen import DecomposingRecordingPen
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont

OUT = Path(__file__).resolve().parents[1]
SOURCE = OUT.parent / "ObelMono-TX02-FiraLiga"
FAMILY = "Obel Mono TX02 Fira Liga 450 900"
PREFIX = "ObelMonoTX02FiraLiga450900"
STYLES = (
    ("Regular", "Regular", 450, False, False),
    ("RegularItalic", "Italic", 450, False, True),
    ("Bold", "Bold", 900, True, False),
    ("BoldItalic", "Bold Italic", 900, True, True),
)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def outlines_match(source, output, weight):
    expected = source.getGlyphSet(location={"wght": weight})
    actual = output.getGlyphSet()
    max_error = 0
    for name in source.getGlyphOrder():
        left = DecomposingRecordingPen(expected)
        right = DecomposingRecordingPen(actual)
        expected[name].draw(left)
        actual[name].draw(right)
        assert len(left.value) == len(right.value), name
        for (op, points), (other_op, other_points) in zip(left.value, right.value):
            assert op == other_op and len(points) == len(other_points), name
            for point, other in zip(points, other_points):
                error = max(abs(a - b) for a, b in zip(point, other))
                assert error <= 1, (name, point, other, error)
                max_error = max(max_error, error)
    return max_error


def shape(path, text, features, weight=None):
    args = ["hb-shape", str(path), "--text=" + text, "--features=" + features,
            "--output-format=json", "--face-loader=ft", "--font-funcs=ft"]
    if weight is not None:
        args.append(f"--variations=wght={weight}")
    return [json.loads(line) for line in subprocess.check_output(args, text=True).splitlines()]


def main():
    assert __debug__, "Run without -O: verification requires assertions"
    fonts = OUT / "ttf"
    fonts.mkdir(exist_ok=True)
    cases = json.loads((SOURCE / "verification/native-cases.json").read_text())
    groups = defaultdict(list)
    for case in cases:
        flags = case.get("features") or {"calt": 1}
        features = ",".join(f"{key}={value}" for key, value in sorted(flags.items()))
        groups[features].append(case["text"])
    # Include positioning, masking, Unicode and multi-line editor text.
    groups["calt=1"].extend([
        "a\u0301 i\u0308 ţ\u0301 Привет б\u0301", "() {} [] 0 a g i l",
        "GITHUB_TOKEN=AbCdabcdef0123456789abcdef0123456789",
        "if (a != b && x <= y) => foo(bar[0]);",
    ])
    report = {"family": FAMILY, "fonttools_version": fontTools.__version__, "fonts": []}
    inputs = {}
    for filename, style, weight, bold, italic in STYLES:
        source_path = SOURCE / "ObelMono/ttf/variable" / (
            "ObelMonoTX02FiraLiga-Italic[wght].ttf" if italic
            else "ObelMonoTX02FiraLiga[wght].ttf")
        inputs[str(source_path.relative_to(OUT.parent))] = sha256(source_path)
        with TTFont(source_path) as source:
            font = instantiateVariableFont(source, {"wght": weight}, static=True)
            # Frozen outlines keep 450/900; standard weight classes enable R/I/B/BI selection.
            font["OS/2"].usWeightClass = 700 if bold else 400
            font["OS/2"].fsSelection = (
                font["OS/2"].fsSelection & ~(1 | 32 | 64 | 512)
            ) | (32 if bold else 0) | (1 if italic else 0) | (
                64 if not bold and not italic else 0)
            font["head"].macStyle = (font["head"].macStyle & ~3) | int(bold) | (int(italic) << 1)
            if "STAT" in font:
                del font["STAT"]
            names = font["name"]
            names.names = [n for n in names.names if n.nameID not in (1, 2, 3, 4, 6, 16, 17, 18, 21, 22, 25)]
            postscript = PREFIX + "-" + filename
            for name_id, value in {
                1: FAMILY, 2: style, 3: f"1.003;TSYS;{postscript}",
                4: FAMILY + " " + style, 6: postscript,
            }.items():
                names.setName(value, name_id, 3, 1, 0x409)
            names.removeUnusedNames(font)
            output_path = fonts / (postscript + ".ttf")
            font.save(output_path)
            font.close()
            with TTFont(output_path, checkChecksums=2) as result:
                assert not set(result.keys()) & {"fvar", "gvar", "avar", "HVAR", "MVAR", "cvar", "STAT"}
                assert result.getGlyphOrder() == source.getGlyphOrder()
                assert result["cmap"].compile(result) == source["cmap"].compile(source)
                assert result["GSUB"].compile(result) == source["GSUB"].compile(source)
                assert result["hhea"].ascent == source["hhea"].ascent
                assert result["hhea"].descent == source["hhea"].descent
                assert result["hhea"].lineGap == source["hhea"].lineGap
                assert result["post"].isFixedPitch == 1
                assert result["post"].italicAngle == (-8.75 if italic else 0)
                assert result["OS/2"].usWeightClass == (700 if bold else 400)
                assert result["OS/2"].fsSelection & 97 == (32 if bold else 0) | (1 if italic else 0) | (64 if not bold and not italic else 0)
                assert result["head"].macStyle & 3 == int(bold) | (int(italic) << 1)
                assert result["name"].getDebugName(1) == FAMILY
                assert result["name"].getDebugName(2) == style
                assert result["name"].getDebugName(6) == postscript
                for name_id in (0, 7, 8, 9, 11, 13, 14):
                    assert result["name"].getDebugName(name_id) == source["name"].getDebugName(name_id)
                max_error = outlines_match(source, result, weight)
                glyph_count = len(result.getGlyphOrder())
            shaping_checks = 0
            for features, texts in groups.items():
                text = "\n".join(texts)
                assert shape(output_path, text, features) == shape(source_path, text, features, weight), (style, features)
                shaping_checks += len(texts)
            report["fonts"].append({
                "file": str(output_path.relative_to(OUT)), "style": style,
                "source_wght": weight, "weight_class": 700 if bold else 400,
                "glyphs_checked": glyph_count, "shaping_checks": shaping_checks,
                "max_outline_coordinate_rounding_units": max_error,
                "sha256": sha256(output_path),
            })
        print(f"PASS {filename}: wght={weight}, {glyph_count} outlines, {shaping_checks} shaping cases", flush=True)
    assert len(list(OUT.rglob("*.ttf"))) == 4
    assert not list(OUT.rglob("*.otf")) and not list(OUT.rglob("*.woff*"))
    for filename in ("AUTHORS.txt", "OFL.txt", "OFL-FiraCode.txt", "LICENSE-TX02.txt", "FEATURES.md", "feature-map.json"):
        shutil.copyfile(SOURCE / filename, OUT / filename)
    for path, digest in inputs.items():
        assert sha256(OUT.parent / path) == digest
    report["inputs_sha256"] = inputs
    report["source_fonts_unchanged"] = True
    report["persistent_installation_performed"] = False
    (OUT / "verification/results.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    shutil.copyfile(SOURCE / "verification/native-cases.json", OUT / "verification/native-cases.json")
    subprocess.run(["swift", str(OUT / "verification/verify_macos.swift"), str(OUT)], check=True)
    archive = OUT.with_suffix(".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as package:
        for path in sorted(OUT.rglob("*")):
            if path.is_file():
                package.write(path, path.relative_to(OUT.parent))
    with zipfile.ZipFile(archive) as package:
        assert package.testzip() is None
        assert sum(name.endswith(".ttf") for name in package.namelist()) == 4
    archive.with_suffix(".zip.sha256").write_text(f"{sha256(archive)}  {archive.name}\n")
    print(f"Packaged {archive.name}: {archive.stat().st_size:,} bytes", flush=True)


if __name__ == "__main__":
    main()
