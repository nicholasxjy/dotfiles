TX-02 Custom SS — 默认启用样式特性的四样式字体包

基于上一版 TX-02 Custom 生成，新字体家族：TX-02 Custom SS。

样式                  wght    wdth    slnt
Regular                450     100       0
Regular Oblique        450     100     -16
Bold                   900     100       0
Bold Oblique           900     100     -16

已固化为默认轮廓，无需应用启用 OpenType 特性开关：
ss02：zero → zero.ss02（0）
ss04：seven → seven.ss04（7）
ss05：r → r.ss05（r）
ss06：bar → bar.ss06（|）
ss09：equal_equal.lig → equal_equal.lig.ss09（== 连字）
      equal_equal_equal.lig → equal_equal_equal.lig.ss09（=== 连字）

重要说明：
源字体公开的 stylistic set 只有 ss01 至 ss06。
ss09 未公开为 feature，但存在上述两个 .ss09 替代字形，
本版使用这些现成字形，并补上了 ss09 特性规则。
ss07 既无现有特性规则，也无可识别的对应替代字形，未能启用。

保留原有 calt 等布局规则、全部 645 个字形、455 个字符映射、
等宽属性、四个样式的关联及源字体版权/许可信息。
== 与 === 的替代外观需要应用支持并启用原有 calt 连字。
即使关闭 ss02/ss04/ss05/ss06/ss09，已固化的默认外观也不会恢复。

安装方式（二选一）：
1. 安装 TX-02-Custom-SS.ttc，一个文件包含四个样式。
2. 若应用不支持 TTC，安装四个 .ttf 文件。
请勿同时安装 TTC 和 TTF，以免出现重复字体条目。

上一版 TX-02 Custom 和原始可变字体均保留。
部分旧应用会把 Oblique 样式显示为 Italic / Bold Italic。
