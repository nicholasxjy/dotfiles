Obel Mono TX02 Fira Liga 450 900 · 1.004
=======================================

以 Obel Mono 1.004 的普通版可变 TTF 为基础，重新移植 TX-02 的六个括号
和 Fira Code 6.002 的连字及字形变体。包含四个静态样式：

  文件后缀          应用内样式       原可变轴 wght    样式字重标记
  Regular.ttf       Regular            450              400
  RegularItalic.ttf Italic             450              400
  Bold.ttf          Bold               900              700
  BoldItalic.ttf    Bold Italic        900              700

字体家族名称：Obel Mono TX02 Fira Liga 450 900
文件名前缀：  ObelMonoTX02FiraLiga450900-

450 / 900 是提取轮廓时的实际字重坐标。字体使用标准的 400 / 700 样式
元数据，供应用切换常规、粗体、斜体和粗斜体。Regular Italic 的内部
样式名为 Italic。

安装与使用
----------
安装 ttf/ 中的四个文件，然后在应用中选择上述家族名称。
1.003 与 1.004 的 450 900 包使用相同的字体家族名与 PostScript 名称。
若已安装 1.003 的 450 900 包，请在字体册中用 1.004 替换对应样式。

VS Code / Cursor：
  "editor.fontFamily": "Obel Mono TX02 Fira Liga 450 900, monospace",
  "editor.fontWeight": "normal",
  "editor.fontLigatures": true

在编辑器中使用 normal / bold（或 400 / 700）选择样式。

每个样式有 2286 个字形，包含 TX-02 括号、默认七项 Fira 样式与全部
42 项可选 Fira 样式。`ss19` 启用 Obel Mono 1.004 的遮罩规则。
完整的 OpenType 开关见 FEATURES.md。

验证与复现
----------
verification/results.json 记录源文件和输出文件的哈希、各字重的全部
字形轮廓检查，以及 HarfBuzz 连字、重音定位和 1.004 遮罩规则的对照。
verification/macos-results.json 记录 CoreText 进程级注册、等宽标签、
原生连字与四种样式的自动选择检查。

在 ObelMono 工作区根目录运行：
  .font-venv/bin/python ObelMono-TX02-FiraLiga-450-900-1.004/verification/build_fonts.py

使用同级的 ObelMono-1.004、TX-02-Variable.ttf、FiraCode-VF.ttf，以及
ObelMono-TX02 和 ObelMono-TX02-FiraLiga 的移植脚本。原生连字测试
沿用旧版用例，按字形名称转换为 1.004 的字形编号。

依赖 fontTools、hb-shape；macOS 原生校验另需 Swift / CoreText。
构建脚本的轮廓自检允许最多 1 个字体单位的整数取整误差。

许可
----
沿用源字体许可，见 AUTHORS.txt、OFL.txt、OFL-FiraCode.txt 和
LICENSE-TX02.txt；字体内部版权、商标和许可文本保留。
TX02 的个人使用限制继续适用。
