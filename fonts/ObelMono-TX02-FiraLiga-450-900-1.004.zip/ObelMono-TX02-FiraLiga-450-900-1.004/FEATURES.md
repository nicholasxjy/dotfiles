# Feature map

默认：`calt=1`，包含七项重点样式。独立选择：`calt=0,ss18=1`，再加所需 Fira 开关。

## Fira styles

Fira 编号保持原样。其余样式在独立模式中可逐项开启。

| Tag | Example | Default |
|---|---|---|
| `ss01` | `r` | 可选 |
| `ss02` | `<= >=` | 开启 |
| `ss03` | `& &&` | 可选 |
| `ss04` | `$ <$ <$> $>` | 可选 |
| `ss05` | `@ ~@` | 可选 |
| `ss06` | `\n \t \\` | 可选 |
| `ss07` | `=~ !~` | 开启 |
| `ss08` | `== === != !==` | 开启 |
| `ss09` | `>>= <<= \|\|= \|=` | 开启 |
| `ss10` | `fi fj fl ft Fl Tl ffi` | 可选 |
| `cv01` | `a á ā` | 可选 |
| `cv02` | `g ĝ ģ` | 可选 |
| `cv03` | `i í ı` | 可选 |
| `cv04` | `i í ı` | 可选 |
| `cv05` | `i í ı` | 可选 |
| `cv06` | `i í ı` | 可选 |
| `cv07` | `l ĺ ł` | 可选 |
| `cv08` | `l ĺ ł` | 可选 |
| `cv09` | `l ĺ ł` | 可选 |
| `cv10` | `l ĺ ł` | 可选 |
| `cv11` | `0` | 可选 |
| `cv12` | `0` | 可选 |
| `cv13` | `0` | 可选 |
| `cv14` | `3 ³ ₃` | 可选 |
| `cv15` | `* ∗` | 可选 |
| `cv16` | `* ** *** /* */` | 可选 |
| `cv17` | `~` | 可选 |
| `cv18` | `% %% ‰` | 可选 |
| `cv19` | `<=` | 可选 |
| `cv20` | `<=` | 可选 |
| `cv21` | `=<` | 可选 |
| `cv22` | `=<` | 可选 |
| `cv23` | `>=` | 可选 |
| `cv24` | `/=` | 可选 |
| `cv25` | `.-` | 开启 |
| `cv26` | `:-` | 开启 |
| `cv27` | `[]` | 可选 |
| `cv28` | `1.2 . .. ... a.b` | 可选 |
| `cv29` | `{} #{` | 可选 |
| `cv30` | `\| \|\| \|\|\| \|= \|\|=` | 可选 |
| `cv31` | `()` | 可选 |
| `cv32` | `.=` | 开启 |

## Original Obel / TX02 features

| Original tag | New tag | Meaning |
|---|---|---|
| `ss01` | `ss19` | Mask secrets |
| `ss02` | `ss20` | Handwritten |
| `cv01` | `cv70` | Dotted zero |
| `cv02` | `cv71` | Single-story a |
| `cv03` | `cv72` | Tailed l |
| `cv04` | `cv73` | Tailed i |
| `cv05` | `cv74` | Tailed j |
| `cv06` | `cv75` | Tailed t |
| `cv07` | `cv76` | Hooked g |
| `cv08` | `cv77` | Descending f |
| `cv09` | `cv78` | Tailed y |
| `cv10` | `cv79` | Plain zero |
| `cv11` | `cv80` | Centered asterisk |
| `cv12` | `cv81` | Broken-bar dollar |
| `cv13` | `cv82` | Open @ |
| `cv14` | `cv83` | Plain 1 |
| `cv15` | `cv84` | Bulgarian forms |
| `cv16` | `cv85` | Serbian forms |

`ss18` 是本构建新增的标准 Fira 连字模式。`ss19` 是普通版秘密遮罩，`ss20` 是原 Obel Handwritten。Masked 版的自动遮罩保留。

只开启相互兼容的字形选项。同一字符的多个互斥样式按 Fira 原查找顺序处理。
