// Register only for this process and check the application's four-style selection.
import Foundation
import CoreText

let root = URL(fileURLWithPath: CommandLine.arguments[1])
let family = "Obel Mono TX02 Fira Liga 450 900"
let prefix = "ObelMonoTX02FiraLiga450900"
let styles: [(String, CTFontSymbolicTraits)] = [
    ("Regular", []), ("RegularItalic", .traitItalic),
    ("Bold", .traitBold), ("BoldItalic", [.traitBold, .traitItalic])
]
let mask: CTFontSymbolicTraits = [.traitBold, .traitItalic]
struct NativeCase: Decodable {
    let text: String
    let glyph_ids: [UInt16]
    let features: [String: Int]?
}
let cases = try JSONDecoder().decode([NativeCase].self, from: Data(contentsOf: root.appendingPathComponent("verification/native-cases.json")))
var failures: [String] = []
var registrations = 0
var shapingChecks = 0
var matches = 0
for (style, _) in styles {
    let url = root.appendingPathComponent("ttf/\(prefix)-\(style).ttf")
    var error: Unmanaged<CFError>?
    if CTFontManagerRegisterFontsForURL(url as CFURL, .process, &error) {
        registrations += 1
    } else {
        failures.append("\(style): registration failed: \(String(describing: error?.takeRetainedValue()))")
    }
}
let regular = CTFontCreateWithName((prefix + "-Regular") as CFString, 16, nil)
for (style, traits) in styles {
    let postscript = prefix + "-" + style
    let font = CTFontCreateWithName(postscript as CFString, 16, nil)
    if CTFontCopyPostScriptName(font) as String != postscript || CTFontCopyFamilyName(font) as String != family {
        failures.append("\(style): incorrect registered font name")
    }
    if CTFontGetSymbolicTraits(font).intersection(mask) != traits {
        failures.append("\(style): incorrect bold/italic traits")
    }
    if !CTFontGetSymbolicTraits(font).contains(.traitMonoSpace) {
        failures.append("\(style): missing monospace trait")
    }
    if let selected = CTFontCreateCopyWithSymbolicTraits(regular, 16, nil, traits, mask),
       CTFontCopyPostScriptName(selected) as String == postscript {
        matches += 1
    } else {
        failures.append("\(style): automatic style selection chose the wrong font")
    }
    let axes = CTFontCopyVariationAxes(font) as? [[String: Any]] ?? []
    if !axes.isEmpty {
        failures.append("\(style): unexpected variable axis")
    }
    for sample in cases {
        var selected = font
        if let features = sample.features, !features.isEmpty {
            let settings = features.sorted(by: { $0.key < $1.key }).map { tag, value in
                [kCTFontOpenTypeFeatureTag as String: tag, kCTFontOpenTypeFeatureValue as String: value] as [String: Any]
            }
            let descriptor = CTFontDescriptorCreateWithAttributes([kCTFontFeatureSettingsAttribute: settings] as CFDictionary)
            selected = CTFontCreateCopyWithAttributes(font, 16, nil, descriptor)
        }
        let attributes = [kCTFontAttributeName: selected, kCTLigatureAttributeName: 1] as CFDictionary
        let attributed = CFAttributedStringCreate(nil, sample.text as CFString, attributes)!
        let line = CTLineCreateWithAttributedString(attributed)
        let runs = CTLineGetGlyphRuns(line) as! [CTRun]
        var actual: [CGGlyph] = []
        for run in runs {
            var glyphs = [CGGlyph](repeating: 0, count: CTRunGetGlyphCount(run))
            CTRunGetGlyphs(run, CFRange(location: 0, length: 0), &glyphs)
            actual += glyphs
        }
        if actual != sample.glyph_ids {
            failures.append("\(style): native shaping mismatch for \(sample.text), \(String(describing: sample.features))")
        }
        shapingChecks += 1
    }
}
for (style, _) in styles {
    let url = root.appendingPathComponent("ttf/\(prefix)-\(style).ttf")
    CTFontManagerUnregisterFontsForURL(url as CFURL, .process, nil)
}
let result: [String: Any] = [
    "family": family, "coretext_process_registrations": registrations,
    "automatic_style_matches": matches, "native_shaping_checks": shapingChecks,
    "failures": failures, "persistent_installation_performed": false
]
let data = try JSONSerialization.data(withJSONObject: result, options: [.prettyPrinted, .sortedKeys])
try data.write(to: root.appendingPathComponent("verification/macos-results.json"))
print(String(data: data, encoding: .utf8)!)
exit(failures.isEmpty && registrations == 4 && matches == 4 ? 0 : 1)
