TX-02 Custom SS — 四种压缩宽度字体包

每个字体家族包含 Regular、Regular Oblique、Bold、Bold Oblique 四个样式。
Regular 字重 450；Bold 字重 900；Oblique 倾斜轴 -16。

SemiCondensed：wdth=90，OpenType 宽度分类 4。
Condensed：wdth=80，OpenType 宽度分类 3。
ExtraCondensed：wdth=70，OpenType 宽度分类 2。
UltraCondensed：wdth=60，OpenType 宽度分类 1。
以上轴值来自源字体对应的命名预设。

默认外观与 TX-02 Custom SS 一致，固化 ss02、ss04、ss05、ss06、ss09。
ss09 使用源字体内置的替代字形；ss07 仍因源文件缺失而无法启用。
== 与 === 的连字外观需要启用应用中的 calt 连字。

共 16 个 TTF、4 个 TTC 及各家族说明。安装各家族的 TTC 即可获得全部四种样式，
也可改装对应的四个 TTF；同一家族的 TTC 与 TTF 不要同时安装。
四种宽度使用独立家族名称，可同时安装。源字体与此前生成的字体包均保留。
