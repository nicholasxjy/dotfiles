TX-02 Custom SS Condensed

基于 TX-02-Variable (1).ttf 的原生 Condensed 预设生成，wdth=80。
沿用 TX-02 Custom SS 的改动，包含四个样式：
Regular / Regular Oblique：wght=450。
Bold / Bold Oblique：wght=900。
Oblique：slnt=-16；直立样式：slnt=0。

ss02、ss04、ss05、ss06、ss09 已固化为默认外观。
ss09 使用源字体内置的 ==、=== 替代字形，并保留相应特性规则。
==、=== 的连字外观需要应用支持并启用 calt。
ss07 在源字体中没有对应规则或可识别的替代字形，未能启用。

保留全部 645 个字形、455 个字符映射、等宽属性、其余布局规则和版权/许可信息。
宽度直接使用源字体可变轴实例化，未对上一版成品作机械缩放。

安装 TX-02-Custom-SS-Condensed.ttc 即可获得四个样式。
若应用不支持 TTC，可改装本目录下四个 TTF。TTC 与 TTF 二选一安装。
部分旧应用会将 Oblique 显示为 Italic / Bold Italic。
